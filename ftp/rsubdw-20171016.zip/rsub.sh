RSUBDIR=$(cd $(dirname $0); pwd)
export JAVAHOME=/rsusr/java/IBM/J8.0
export PATH=$JAVAHOME/bin:$PATH
export CLASSPATH=$RSUBDIR/rsub.jar:$RSUBDIR/commons-net-3.6.jar:$RSUBDIR
java RemoteJclSubmitter $@
