import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPConnectionClosedException;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.PrintCommandListener;

/**
 * This is a program to submit a JCL to a remote host. See below for further
 * options.
 */
public final class RemoteJclSubmitter {

	static String propfile = "rsub.properties";
	public static final String USAGE = "Expected Parameters: <host> <JCLfile>" 
	        + " (options)\n\n"
			+ "\t-u <userid>          Userid to submit <JCLfile> to <host>.\n"
			+ "\t-p <password>        Password to submit <JCLfile> to <host>.\n"
			+ "\t-r <retrycount>      Maximum retry attempts to retrieve job output.\n"
			+ "\t-w <waitsecond>      Wait time, in seconds, to retrieve job output.\n"
			+ "\t-o <outputfile>      Job output file. Default is <JCLfile>.Jxxxxxxx.log.\n" 
			+ "\t-f <ftplogfile>      FTP log file. Default is <JCLfile>.rsubftp.log.\n"
			+ "\t-xb <xferbeforejob>  Transfer file list before submitting <JCLfile>.\n"
			+ "\t-xa <xferafterjob>   Transfer file list after the completion of <JCLfile> job.\n" 
			+ "\t-qs <quotestart>     QUOTE SITE command file at the start.\n"
			+ "\t-qb <quotebeforejob> QUOTE SITE command file before submitting <JCLfile>.\n"
			+ "\t-qa <quoteafterjob>  QUOTE SITE command file after the completion of <JCLfile> job." 
			+ "\n\tIf these options are not supplied, values in " + propfile + " are used as default values.\n"
			+ "\nThe default behavior of this program is to submit <JCLfile> to <host> by using"
			+ " the values in " + propfile + " or the values supplied at run time.\n"
			+ "In addition, if the -xb option is specified, files in <xferbeforejob> are"
			+ " transferred before submitting <JCLfile>.\n"
			+ "Also, if the -xa option is specified, files in <xferafterjob> are transferred"
			+ " after the completion of <JCLfile> job.\n";
	static String haspmsg = "$HASP395";   // JES job end message
	static String jclerr = "- JCL ERROR"; // JCL error
	static int rc_fatal = 16;             // fatal error return code
	static int rc_severe = 12;            // severe error return code
	static int rc_error = 8;              // error return code
	static int rc_warning = 4;            // warning return code
	String classname = null;              // this class name
	DateFormat sdf = null;                // date format
	Date curdate = null;                  // current date
	FTPClient ftp = null;                 // FTP client
	int ftpdefault = FTP.ASCII_FILE_TYPE; // FTP default data type
	int currentftpmode = FTP.BINARY_FILE_TYPE; // current FTP mode

	boolean error = false;
	int minParams = 2;
	int returncode = 0;
	InputStream input = null;
	OutputStream output = null;
	
	// parameter options 
	String host = null;
	String jclfile = null;
	String userid = null;
	String password = null;
	String ftplogfile = null;
	String outputfile = null;
	String xferbeforejob = null;
	String xferafterjob = null;
	String quotestart = null;
	String quotebeforejob = null;
	String quoteafterjob = null;
	int retrycount = 0;
	int waitsec = 0;
	
	// constructor
	RemoteJclSubmitter(String[] args) {
		classname = this.getClass().getSimpleName();
		sdf = new SimpleDateFormat("HH:mm:ss");

		// load property file
		Properties properties = new Properties();
		try {
			properties.load(getClass().getResourceAsStream("/"+propfile));
			userid = properties.getProperty("userid");
			password = properties.getProperty("password");
			ftplogfile = properties.getProperty("ftplogfile");
			outputfile = properties.getProperty("outputfile");
			quotestart = properties.getProperty("quotestart");
			quotebeforejob = properties.getProperty("quotebeforejob");
			quoteafterjob = properties.getProperty("quoteafterjob");
			xferbeforejob = properties.getProperty("xferbeforejob");
			xferafterjob = properties.getProperty("xferafterjob");
			retrycount = Integer.parseInt(properties.getProperty("retrycount"));
			waitsec = Integer.parseInt(properties.getProperty("waitsecond"));
		} catch (Exception ex) {
			System.err.println(prefmsg()+" failed to load "+propfile+".");
			ex.printStackTrace();
			System.exit(rc_fatal);
		}

		// check required parameters
		int base = 0;
		if (args.length < minParams) // host, JCLfile
		{
			if (args.length > 0) {
				System.err.println(prefmsg()
						+ " did not get required parameters.");
			}
			System.err.println("\n" + USAGE);
			System.exit(rc_fatal);
		}
		host = args[base++];
		jclfile = args[base++];

		// check options
		int opt = base;
		try {
			for (opt = base; opt < args.length; opt++) {
				if (args[opt].equals("-w")) {
					waitsec = Integer.parseInt(args[++opt]);
				} else if (args[opt].equals("-r")) {
					retrycount = Integer.parseInt(args[++opt]);
				} else if (args[opt].equals("-u")) {
					userid = args[++opt];
				} else if (args[opt].equals("-p")) {
					password = args[++opt];
				} else if (args[opt].equals("-o")) {
					outputfile = args[++opt];
				} else if (args[opt].equals("-f")) {
					ftplogfile = args[++opt];
				} else if (args[opt].equals("-qs")) {
					quotestart = args[++opt];
				} else if (args[opt].equals("-qb")) {
					quotebeforejob = args[++opt];
				} else if (args[opt].equals("-qa")) {
					quoteafterjob = args[++opt];
				} else if (args[opt].equals("-xb")) {
					xferbeforejob = args[++opt];
				} else if (args[opt].equals("-xa")) {
					xferafterjob = args[++opt];
				} else {
					break;
				}
			}
		} catch (Exception ex) {
			System.err.println(prefmsg() + " got invalid option :\n" 
					+ args[opt-1] + " " + args[opt]); 
			ex.printStackTrace();
			System.err.println("\n" + USAGE);
			System.exit(rc_fatal);
		}

		// check userid and password
		if ((userid == null || userid.length() == 0) || 
				(password == null || password.length() == 0)) {
			System.err.println(prefmsg()+" did not get userid/password in "
					+ propfile + " or options.");
			System.err.println("\n" + USAGE);
			System.exit(rc_fatal);
		}

		// check output file is not the same as input file
		if ((outputfile != null) && (outputfile.equals(jclfile))) {
			System.err.println(prefmsg() 
					+ " got same output file name as " + jclfile + ".");
			System.exit(rc_fatal);
		}

		// check ftp log is not the same as input file
		if ((ftplogfile == null) || (ftplogfile.length() == 0)) {
			ftplogfile = jclfile + ".rsubftp.log";
		} else if (ftplogfile.equals(jclfile)) {
			System.err.println(prefmsg() 
					+ " got same ftp log file name as " + jclfile + ".");
			System.exit(rc_fatal);
		}

		// check input file exists
		File localfile = new File(jclfile);
		if (!localfile.exists()) {
			System.err.println(prefmsg() + " got '" + jclfile 
					+ "' file that does not exist.");
			System.exit(rc_fatal);
		}

		// check quotestart file exists
		if ((quotestart != null) && (quotestart.length() != 0)) {
			localfile = new File(quotestart);
			if (!localfile.exists()) {
				System.err.println(prefmsg() + " got '" + quotestart 
						+ "' file that does not exist.");
				System.exit(rc_fatal);
			}	
		}

		// check quotebeforejob file exists
		if ((quotebeforejob != null) && (quotebeforejob.length() != 0)) {
			localfile = new File(quotebeforejob);
			if (!localfile.exists()) {
				System.err.println(prefmsg() + " got '" + quotebeforejob 
						+ "' file that does not exist.");
				System.exit(rc_fatal);
			}	
		}

		// check quoteafterjob file exists
		if ((quoteafterjob != null) && (quoteafterjob.length() != 0)) {
			localfile = new File(quoteafterjob);
			if (!localfile.exists()) {
				System.err.println(prefmsg() + " got '" + quoteafterjob 
						+ "' file that does not exist.");
				System.exit(rc_fatal);
			}	
		}

		// check xferbeforejob file exists
		if ((xferbeforejob != null) && (xferbeforejob.length() != 0)) {
			localfile = new File(xferbeforejob);
			if (!localfile.exists()) {
				System.err.println(prefmsg() + " got '" + xferbeforejob 
						+ "' file that does not exist.");
				System.exit(rc_fatal);
			}	
		}

		// check xferafterjob file exists
		if ((xferafterjob != null) && (xferafterjob.length() != 0)) {
			localfile = new File(xferafterjob);
			if (!localfile.exists()) {
				System.err.println(prefmsg() + " got '" + xferafterjob 
						+ "' file that does not exist.");
				System.exit(rc_fatal);
			}	
		}
		
		// check system code
		String notASCII = System.getProperty("platform.notASCII");
		if ((notASCII != null) && notASCII.equals("true")) {
			ftpdefault = FTP.EBCDIC_FILE_TYPE;
		}
	}
	
	// prefix message 
	String prefmsg() {
		curdate = new Date();
		return sdf.format(curdate) + " " + classname;
	}

	// main routine
	public static void main(String[] args) {
		RemoteJclSubmitter obj = new RemoteJclSubmitter(args);
		obj.ftpProcess();
	} // end main
	
	// change ftp mode if necessary                        
	public void changeftpmode(int newftpmode) throws IOException {
		if (newftpmode != currentftpmode) {
			ftp.setFileType(newftpmode);
			currentftpmode = newftpmode;
		}
	}
	
	public void ftpProcess() {
		// initialize ftp client
		ftp = new FTPClient();

		// set up to write ftp log file
		try {
			ftp.addProtocolCommandListener(new PrintCommandListener(
					new PrintWriter(new BufferedWriter(new FileWriter(new File(
							ftplogfile)))), true));
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// connect to host 
		try {
			int reply;
			ftp.connect(host);

			// check the reply code to verify success
			reply = ftp.getReplyCode();

			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				System.out.println(prefmsg()+" failed to connect "
						+ host +".");
				error = true;
			}
		} catch (Exception e) {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException f) {
					// do nothing
				}
			}
			System.out.println(prefmsg()+" could not connect to "
					+ host +".");
			e.printStackTrace();
			error = true;
		}

		__main: try {
			// check error occurred 
			if (error) {
				break __main;
			}

			// login ftp by using userid or password 
			if (!ftp.login(userid, password)) {
				System.out.println(prefmsg()+" FTP login failed.");
				ftp.logout();
				error = true;
				break __main;
			}
			System.out.println(prefmsg()+" FTP session started.");
			
			// send QUOTE SITE command if necessary
			runCommand('Q',quotestart);

			// transfer files if necessary 
			changeftpmode(ftpdefault);
			runCommand('T',xferbeforejob);
			changeftpmode(ftpdefault);

			// send QUOTE SITE command for JES     
			runCommand('Q',quotebeforejob);
			ftp.sendCommand("SITE", "FILETYPE=JES JESJOBNAME=*");

			// submit JCL file
			input = new FileInputStream(jclfile);
			ftp.storeFile(jclfile, input);
			String replyString = ftp.getReplyString();
			input.close();
			
			// check JOB number in JES reply
			String jobnum = "";
			String jesstr = "to JES as ";
			int pos = replyString.indexOf(jesstr);
			if (pos != -1) {
				pos = pos + jesstr.length();
				jobnum = replyString.substring(pos, pos + 8);
				
				// check JOB number is valid
				if (jobnum.substring(0,1).equals("J")) { 
					System.out.println(prefmsg() + " submitted "+ jclfile 
							+ " to " + host	+ " as " + jobnum + ".");
					
					/// set output file name when it is not specified
					if ((outputfile == null) || (outputfile.length() == 0)) {
						outputfile = jclfile + "." + jobnum + ".log";
					}
					
					// get JOB output with JOB end until retry count is reached
					for (int i = 0; true;) {
						try {
							Thread.sleep(1000*waitsec);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
						// get JES message log file first
						output = new FileOutputStream(outputfile);
						ftp.retrieveFile(jobnum + ".1", output);
						output.close();
						
						// check the reply code
						replyString = ftp.getReplyString();
						if (FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
							// get job end message in JES message log file
							String endmsg = getJobEnd(outputfile);

							// get entire JOB output
							output = new FileOutputStream(outputfile);
							ftp.retrieveFile(jobnum, output);
							output.close();
							
							// check the reply code
							if (FTPReply.isPositiveCompletion(
									ftp.getReplyCode())) {
								System.out.println(prefmsg() + " created "
										+ outputfile + " from "  + host 
										+ " :\n" + endmsg);

								// check job end message
								pos = endmsg.indexOf(haspmsg);
								if (pos != -1) {

									// check return code in z/OS V2 message
									String jobrc;
									pos = endmsg.indexOf("RC=");
									if (pos != -1) {
										jobrc = endmsg.substring(pos+3, pos+7);
										if (!jobrc.equals("0000")) {
											System.out.println(prefmsg()
													+ " detected non-zero "
													+ "return code <" + jobrc 
													+ "> in " + jobnum + ".");
											returncode = rc_warning;
										}
									}
								} else {
									// check JCL error
									pos = endmsg.indexOf(jclerr);
									if (pos != -1) {
										System.out.println(prefmsg()
												+ " detected JCL error in "
												+ jobnum + ".");
										returncode = rc_warning;
									} else {
										System.out.println(prefmsg()
												+ " could not detect job end"
												+ " in " + jobnum + ".");
										returncode = rc_warning;
									}
								}
								
								ftp.deleteFile(jobnum);   // delete job
								break;  // exit for-loop 
							}
						}
						
						// check retry count is reached
						if (i >= retrycount) {
							System.out.println(prefmsg() + " failed to get "
									+ jobnum + " :\n" + replyString);
							returncode = rc_error;
							break;  // exit for-loop
						}
						
						// retry to get job output
						i++;
						System.out.println(prefmsg() + " retrying to get " 
								+ jobnum + " in " + waitsec + " seconds (" 
								+ i + ").");
					}  // end for-loop
				} else {  // invalid JOB number
					System.out.println(prefmsg() + " submitted " 
							+ jclfile + " to " + host 
							+ " as invalid JOB <" + jobnum 
							+ "> :\n" + replyString);
					returncode = rc_error;
				}
			} else {
				System.out.println(prefmsg() + " failed to submit " 
						+ jclfile + " to " + host + " :\n" + replyString);
				returncode = rc_error;
			}

			// transfer files if necessary                                           
			if ((xferafterjob != null) && (xferafterjob.length() != 0)) {
				runCommand('Q',quoteafterjob);
				ftp.sendCommand("SITE", "FILETYPE=SEQ");
				runCommand('T',xferafterjob);
			}

			ftp.noop(); // check that control connection is working OK

			ftp.logout();
		} catch (FTPConnectionClosedException e) {
			error = true;
			System.out.println(prefmsg() 
					+ " got FTP connection closed exception.");
			e.printStackTrace();
		} catch (Exception e) {
			error = true;
			e.printStackTrace();
		} finally {
			if (ftp.isConnected()) {
				try {
					ftp.disconnect();
				} catch (IOException f) {
					// do nothing
				}
			}
		}

		// exit with final message including return code
		int rc = (error ? rc_severe : returncode);
		System.out.println(prefmsg() + " ended with RC=" + rc +"."); 
		System.exit(rc);
	}

	// get line including haspmsg or jclerr in file 
	public String getJobEnd(String filePath) {
		String endmsg = "";
		int pos;
		FileReader fr = null;
		BufferedReader br = null;
		try {
			String line = "";
			fr = new FileReader(filePath);
			br = new BufferedReader(fr);

			// read file 
			while ((line = br.readLine()) != null) {
				// check JOB end message
				pos = line.indexOf(haspmsg);
				if (pos == -1) {
					pos = line.indexOf(jclerr);
				}	
				if (pos != -1) {
					endmsg = line;
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return endmsg;
	}
	// run ftp command accordingly     
	public void runCommand(char command, String filePath) {
		if (filePath == null || filePath.length() == 0) {
			return;
		}
		String[] str = null;
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(filePath);
			br = new BufferedReader(fr);

			// read file 
			String line, linetrim;
			while ((line = br.readLine()) != null) {
				linetrim = line.trim();
				if (!linetrim.equals("")) {
					if (command == 'Q') {  // QUOTE SITE
						ftp.sendCommand("SITE", linetrim);
					} else {               // transfer files
						// split line by ","
						str = linetrim.split(",");
						
						// 1st and 2nd tokens are mandatory 
						if ((str.length >= 2 ) &&
								(str[0] != null) && 
								(str[0].trim().length() != 0) &&
								(str[1] != null) &&
								(str[1].trim().length() != 0)) {
							
							// 1st token must be "g" or "p" 
							if (("g".equalsIgnoreCase(str[0])) ||
									("p".equalsIgnoreCase(str[0]))) {

								// copy 2nd token to omitted 3rd token 
								if (str.length <= 2) {
									String[] tstr = new String[3];
									tstr[0] = str[0];
									tstr[1] = str[1];
									tstr[2] = str[1];
									str = tstr;
								}
								if (str[2].trim().length() == 0) {
									str[2] = str[1];
								}
								
								// change ftp mode according to 4th token
								if ((str.length>=4) && 
										"b".equalsIgnoreCase(str[3])) {
									changeftpmode(FTP.BINARY_FILE_TYPE);
								} else {
									changeftpmode(ftpdefault);
								}
								
								// get or put files accordingly
								if ("g".equalsIgnoreCase(str[0])) { // GET 
									output = new FileOutputStream(str[2]);
									ftp.retrieveFile(str[1], output);
									output.close();
								} else {                            // PUT
									input = new FileInputStream(str[1]);
									ftp.storeFile(str[2], input);
									input.close();
								}

								// check result of file transfer
								if (!FTPReply.isPositiveCompletion(
										ftp.getReplyCode())) {
									System.out.println(prefmsg()
											+ " failed to transfer "
											+ str[1] + " :\n"
											+ ftp.getReplyString());
									if (returncode < rc_warning) {
										returncode = rc_warning;
									}
								}
							}
						}
					}
				}
			}
		} catch (IOException e) {
			System.out.println(prefmsg()
					+ " failed to transfer "
					+ str[1] + " :\n"
					+ e.getMessage());
			if (returncode < rc_warning) {
				returncode = rc_warning;
			}
		} finally {
			try {
				br.close();
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}