Contents of zip file

  btsafter.txt            : transfer file list used in btsclient.cmd after submitting btssamp2.jcl
  btsbefore.txt           : transfer file list used in btsclient.cmd before submitting btssamp2.jcl
  btsclient.cmd           : sample Windows command file to run BTS
  btsin.txt               : sample transaction definition used in btsclient.cmd
  btssamp2.jcl            : sample BTS jcl used in btsclient.cmd
  null.data               : null data used in btsclient.cmd
  readme.txt              : readme file
  RemoteJclSubmitter.java : sample java source file
  rsub.cmd                : sample Windows command file to run the java code  
  rsub.jar                : jar file including RemoteJclSubmitter.class
  rsub.properties         : properties file for default values in RemoteJclSubmitter.java
  rsub.sh                 : sample Unix/Linux command file to run the java code
  
How to run sample code
  1. Extract the .zip file to an arbitrary location.
  2. Download the Appache Commons Net Libarary and save the binaries (commons-net-3.6.jar as of 2017/10) to the same location.
  3. Edit rsub.cmd for Windows or rsub.sh for Unix to match your environment.
  4. Open rsub.properties and change xxxxx to your FTP user ID and yyyyyyyy to your FTP password. 
     The values set in rsub.properties are used as default values but you can change them at run time by using program parameters.
  5. Run rsub.cmd or rsub.sh with the host name and the local file name.
  
Program interface

  Expected Parameters: <host> <JCLfile> (options)
      -u <userid>          Userid to submit <JCLfile> to <host>.
      -p <password>        Password to submit <JCLfile> to <host>.
      -r <retrycount>      Maximum retry attempts to retrieve job output.
      -w <waitsecond>      Wait time, in seconds, to retrieve job output.
      -o <outputfile>      Job output file. Default is <JCLfile>.Jxxxxxxx.log.
      -f <ftplogfile>      FTP log file. Default is <JCLfile>.rsubftp.log.
      -xb <xferbeforejob>  Transfer file list before submitting <JCLfile>.
      -xa <xferafterjob>   Transfer file list after the completion of <JCLfile> job.
      -qs <quotestart>     QUOTE SITE command file at the start.
      -qb <quotebeforejob> QUOTE SITE command file before submitting <JCLfile>.
      -qa <quoteafterjob>  QUOTE SITE command file after the completion of <JCLfile> job.
      If these options are not supplied, values in rsub.properties are used as default values.
  The default behavior of this program is to submit <JCLfile> to <host> by using the values in rsub.properties or the values supplied at run time.
  In addition, if the -xb option is specified, files in <xferbeforejob> are transferred before submitting <JCLfile>.
  Also, if the -xa option is specified, files in <xferafterjob> are transferred after the completion of <JCLfile> job.
    
  Return code:
  0  : Normal end
  4  : Warning
  8  : Error
  12 : Severe error
  16 : Fatal error
